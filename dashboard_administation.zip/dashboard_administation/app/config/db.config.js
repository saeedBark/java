module.exports = {
  HOST: "localhost",
  PORT: 33061,
  USER: "mdhamed",
  PASSWORD: "0413",
  DB: "nodemysql",
};
