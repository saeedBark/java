import java.io.*;
import java.net.*;

class Service extends Thread {
  private Socket service;
  public Service(Socket s) { service = s; }
  public void run() {
    try {
      System.out.println("Je suis un service qui prend la main");
      OutputStream os  = service.getOutputStream();
      PrintWriter pw = new PrintWriter(os);
      try {
        Thread.sleep(600000);
      } catch(Exception ex) {
      }
      pw.println("Bonjour");
      pw.flush();
      System.out.println("Service : J'ai terminé mon boulot");
      service.close();
    } catch(Exception e) {
      System.err.println(e);
    }
  }
}

public class Serveur {
  public static void main(String []args) {
    try {
      ServerSocket s = new ServerSocket(60000);
      do {
        System.out.println("Serveur en attente");
        Socket service  = s.accept();
        System.out.println("Un client vient d'arriver");
        Service leService = new Service(service);
        leService.start();
      } while(true);
    } catch(Exception e) {
      System.err.println(e);
    }
  }
}

